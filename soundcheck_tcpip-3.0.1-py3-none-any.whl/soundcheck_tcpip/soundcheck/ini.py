from configparser import ConfigParser, DuplicateSectionError


class SCIni():
    """Class that provides an API to reading/writing the SoundCheck INI file"""

    def __init__(self, ini_path):
        self._ini_path = ini_path

    def get_option(self, section, option, default=None, get_type=None):
        """Read an option from the SoundCheck INI file.

        Attempt to open the SoundCheck INI file and read option from section.
        If the file, section, or option does not exist, return default if
        provided, else raise a ValueError. If get_type is not None, try to use
        the get{get_type} method of ConfigParser to retrieve the value.

        :param section: str name of section to find
        :param option:  str name of the option in section to find
        :param default: default value (optional)
        :param get_type: str alternate get method to use. (boolean, float, int)
        :return: value from the INI file
        """

        def check_value(validator, args, check_type, has_default):
            if validator(*args):
                return True
            if has_default is not None:
                return False
            raise ValueError(f'Could not find ini {check_type}: {args[-1]}')

        config = SCConfigParser()
        config.optionxform = str
        config._comment_prefixes = ('#', ';', '//')
        config.read(self._ini_path)

        if not check_value(config.has_section, [section], 'section', default):
            return default
        if not check_value(config.has_option, [section, option], 'option',
                           default):
            return default

        if get_type is None:
            value = config.get(section, option)
        else:
            get_method = getattr(config, f'get{get_type}')
            value = get_method(section, option)

        return value

    def set_option(self, section, option, value):
        """Set an option in the SoundCheck INI file.

        Attempt to open the SoundCheck INI file and set option in section to
        value.

        :param section: str name of section to find
        :param option:  str name of the option in section to find
        :param value: value to set
        """
        config = SCConfigParser()
        config.optionxform = str
        config._comment_prefixes = ('#', ';', '//')
        config.read(self._ini_path)

        # deal with python2/3 madness
        val_str = str(value)
        if hasattr(val_str, 'decode'):
            val_str = val_str.decode('utf-8')

        config.set(section, option, val_str)
        with open(self._ini_path, 'w') as f:
            config.write(f)


class SCConfigParser(ConfigParser):
    """Subclass ConfigParser to handle quirks of the SoundCheck INI files.

    In typical SoundCheck fashion, the ini files are not consistent with
    stored values, and many are wrapped in unnecessary double quotes. The
    Python ConfigParser doesn't play nice with this format by default, so
    override the base get method to strip double quotes from values."""
    _UNSET = object()

    def __init__(self):
        super().__init__(strict=False)

    def get(self, section, option, raw=False, vars=None, fallback=_UNSET):
        """Same as the parent get method, but strip double quotes."""
        val = ConfigParser.get(self, section, option, raw=raw,
                               vars=vars, fallback=fallback)
        try:
            return val.strip('"')
        except AttributeError:
            return val

    def read(self, filenames, encoding=None):
        """The ConfigParser sometimes throws bogus (at least they seem to be)
        exceptions.  Sometimes it's a DuplicateKey (which shouldn't happen since
        we're instantiating the parser with strict=False), other times it's a
        ParserError.  Catch these instances and give it another try or dump
        the contents of the ini file for diagnosis."""

        def dump_ini_file(filename):
            with open(filename, 'r') as f:
                ini_contents = f.read()
                print(ini_contents)

        try:
            file_read = super().read(filenames, encoding)

        except DuplicateSectionError as e:
            print(f'Duplicate Section Error: {e}')
            print(f'Dumping INI file')
            dump_ini_file(filenames)
            raise

        except BaseException as e:
            print(f'Unexpected exception: {e}')
            print(f'Dumping INI file')
            dump_ini_file(filenames)

            print(f'Trying again')
            file_read = super().read(filenames, encoding)

        return file_read
