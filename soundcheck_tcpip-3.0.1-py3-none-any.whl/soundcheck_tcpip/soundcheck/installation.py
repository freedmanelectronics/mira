from __future__ import absolute_import, unicode_literals

import platform
import shutil
import stat
import subprocess
import time
from pathlib import Path
from .ini import SCIni

from .agent import SCAgent
from .version import filter_version_strings, get_file_version


def construct_installation(version=None, path=Path()):
    """Build the appropriate installation subclass for the current platform.

    :param version: SCVersion or int iterable [major, minor, patch, build]
    :param path: path to the install directory for an active install
    :return: platform appropriate instance of SCInstallation
    """
    platform_types = {'Windows': WinSCInstallation,
                      'Darwin': MacSCInstallation}

    installation = platform_types.get(platform.system(), SCInstallation)

    return installation(version=version, path=path)


def construct_remote_installation(ip_address=None, port=None):
    """Build the  installation subclass for a SoundCheck installation on
    another computer.

    :param ip_address of the computer running the SoundCheck to connect to
    :param port on the computer running SoundCheck to connect to
    :return: an SCInstallation for the remote installation of SoundCheck
    """

    return RemoteSCInstallation(ip_address=ip_address, port=port)


class SCInstallation(SCAgent):
    """Class to manage a particular installed version of SoundCheck."""

    def __init__(self, version=None, path=Path(), ip_address=None, port=None):
        super(SCInstallation, self).__init__(version=version, path=path, ip_address=ip_address, port=port)
        self.agent_type = 'installation'
        self.process = None
        self._verify_version()
        self._ini = None

    def __del__(self):
        if self.process:
            self.process.terminate()

    @property
    def ini(self):
        if self._ini is None:
            self._ini = SCIni(self.ini_path())

        return self._ini

    def get_activation_prerequisites(self):
        """Get the prerequisites for activating this agent.

        An installation is already active, so there are no requirements or
        conflicts to activation from other installations.

        :return: dict of requirements
        """
        prereqs = super(SCInstallation, self).get_activation_prerequisites()
        prereqs['require_v_min'] = None
        prereqs['require_v_max'] = None
        prereqs['conflict_v_min'] = None
        prereqs['conflict_v_max'] = None
        return prereqs

    def activate(self, timeout=None):
        """Confirm that this installation is active.

        Since this SCAgent is already an installation, no actions should need
        to be taken. However, the return value should reflect whether or not
        the installation is now available on the system, so some basic checks
        are performed here.

        :param timeout: amount of time before the install times out
        :return: bool True if activation successful, else False
        """
        return self.is_valid()

    def is_valid(self):
        """Test that the installation is valid.

        :return: bool True if valid, else False
        """
        if not self.path.is_dir():
            return False
        if (self.launcher_path() is None
                or not self.launcher_path().exists()):
            return False
        return True

    def tcpip_enabled(self):
        """Return whether TCP/IP is already enabled on this installation."""
        return False

    def launcher_path(self):
        """Get the path to the SoundCheck executable.

        This checks for files in the installation folder that match the
        prescribed naming convention. The path to the first suitable launcher
        file with an embedded version consistent with self.version is
        returned. If no matches are found, None is returned.

        :return: str path to the executable, or None if not found
        """
        dir_list = [el.name for el in self.path.iterdir()]

        matches = filter_version_strings(dir_list,
                                         version=self.version[:1],
                                         prefix='SoundCheck ',
                                         suffix=self._launcher_suffix())
        for m in matches:
            full_path = self.path / m
            if self.version.is_consistent(get_file_version(full_path)):
                return full_path
        return None

    def ini_path(self):
        """Get the path to the SoundCheck INI file.

        :return: str path to the ini file, or None if not found
        """
        for precision in range(1, 3):
            ini_name = f'SoundCheck {self.version.to_str(precision)}.ini'
            ini_path = self.path / ini_name
            if ini_path.exists():
                return ini_path
        raise IOError('Could not find ini file for this installation.')

    def get_ini_option(self, section, option, default=None, get_type=None):
        """Read an option from the SoundCheck INI file.

        Attempt to open the SoundCheck INI file and read option from section.
        If the file, section, or option does not exist, return default if
        provided, else raise a ValueError. If get_type is not None, try to use
        the get{get_type} method of ConfigParser to retrieve the value.

        :param section: str name of section to find
        :param option:  str name of the option in section to find
        :param default: default value (optional)
        :param get_type: str alternate get method to use. (boolean, float, int)
        :return: value from the INI file
        """

        return self.ini.get_option(section, option, default, get_type)

    def set_ini_option(self, section, option, value):
        """Set an option in the SoundCheck INI file.

        Attempt to open the SoundCheck INI file and set option in section to
        value.

        :param section: str name of section to find
        :param option:  str name of the option in section to find
        :param value: value to set
        """

        self.ini.set_option(section, option, value)

    def server_details(self):
        section = 'External Control'
        try:
            tcp_enabled = self.get_ini_option(section, 'TCP IP SERVER ENABLED',
                                              default=False, get_type='boolean')
        except IOError:
            tcp_enabled = False

        if tcp_enabled:
            ip_address = '127.0.0.1'  # seems only local is allowed.
            port = self.get_ini_option(section, 'TCP IP SERVER PORT',
                                       default=None, get_type='int')
            return ip_address, port
        return None, None

    def import_ini(self, new_file):
        self._import_sc_file(self.ini_path(), Path(new_file))

    def import_har(self, new_file):
        har_path = self.path / 'Steps' / 'Hardware' / 'System.Har'
        self._import_sc_file(har_path, Path(new_file))

    def import_cal(self, new_file):
        cal_path = self.path / 'Steps' / 'Calibration' / 'System.Cal'
        self._import_sc_file(cal_path, Path(new_file))

    def import_cal_input_dat(self, new_file):
        """Imports a Calibration .dat file for an input device.  Must also import a .cal that references the .dat

        :param new_file: str of path and filename to the .dat file to import
        """
        dat_path = self.path / 'Steps' / 'Calibration' / "Input Calibration Data" / Path(new_file).name
        self._import_sc_file(dat_path, Path(new_file))

    def import_cal_output_dat(self, new_file):
        """Imports a Calibration .dat file for an output device.  Must also import a .cal that references the .dat

        :param new_file: str of path and filename to the .dat file to import
        """
        dat_path = self.path / 'Steps' / 'Calibration' / "Output Calibration Data" / Path(new_file).name
        self._import_sc_file(dat_path, Path(new_file))

    def is_running(self):
        if self.process is not None:
            return self.process.poll() is None  # process is running if None
        return False

    def launch(self):
        self.terminate()
        self.process = self._perform_launch()
        return self.process

    def send_exit(self):
        return True

    def terminate(self):
        if self.process:
            self.process.terminate()
            self.process = None

    def uninstall(self, cleanup=True):
        raise NotImplementedError

    def cleanup(self):
        """Delete the installation directory.

        :return: True if self.path is not a directory anymore
        """
        if not self.path:
            return True
        if self.path.is_dir():
            print(f'Removing SoundCheck directory: {self.path}')
            try:
                shutil.rmtree(self.path, onerror=remove_readonly)
            except OSError as err:
                print(f'Error attempting to clean up: {err}')
        return not self.path.is_dir()

    @staticmethod
    def _import_sc_file(current_file, new_file):
        """Replace a file in the current installation in a "safe" way, using
        the current file as a temp

        :param current_file: current file location, file being replaced
        :param new_file: file to be imported
        :return: None if an error occurs, otherwise returns current_file
        """
        if not new_file.exists():
            print(f"Error in _import_sc_file: new file '{new_file}' was not found")
            return None

        if not current_file.exists():
            temp_path = None
        else:
            current_file_path = current_file

            permissions = current_file_path.stat()
            if not permissions.st_mode & stat.S_IWUSR:
                print(f"Warning in _import_sc_file: existing file '{current_file_path}' is read-only. Changing permissions to read/write.")
                current_file_path.chmod(permissions.st_mode | stat.S_IWUSR)

            # Get file extension
            ext = current_file_path.suffix
            temp_name = f'temp{ext}'
            temp_path = Path(current_file_path.parent, temp_name)
            shutil.copy(current_file, temp_path)
            current_file_path.unlink()

        try:
            shutil.copy(new_file, current_file)
        except (IOError, OSError):
            shutil.copy(temp_path, current_file)

        if temp_path and temp_path.exists():
            temp_path.unlink()

        return current_file

    def _perform_launch(self):
        if self.launcher_path() is None:
            raise IOError('Could not find SoundCheck launcher.')

    def _launcher_suffix(self):
        raise NotImplementedError

    def _verify_version(self):
        """Verify that launcher and installation versions are consistent.

        This uses the OS to get the file version reported by the launcher. If
        the launcher version is not found or is inconsistent with the
        installation version, a IOError or RuntimeError will be
        raised, respectively.

        If the versions are consistent and the launcher version is more
        precise, the installation version will be updated to match.
        """
        launcher_path = self.launcher_path()
        if launcher_path is None:
            raise IOError('Could not find SoundCheck launcher.')
        launcher_version = get_file_version(launcher_path)

        # versions are guaranteed to be consistent by self.launcher_path()
        # but launcher might be more precise
        if len(launcher_version) > len(self.version):
            self.version = launcher_version


class WinSCInstallation(SCInstallation):
    def _launcher_suffix(self):
        return '.*[.]exe'

    def _perform_launch(self):
        super(WinSCInstallation, self)._perform_launch()

        return subprocess.Popen(f'"{self.launcher_path()}"', shell=True,
                                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP)

    def uninstall(self, cleanup=True):
        """Uninstall SoundCheck, with optional cleanup after.

        :param cleanup: if True, remove the directory after successful uninstall
        :return: status code of the subprocess
        """
        uninstaller_path = self.path / 'Uninstaller.exe'
        if (not uninstaller_path.exists()
                or not uninstaller_path.is_file()):
            print(f'\tUninstaller not found: {uninstaller_path}')
            return

        completed_process = subprocess.run(f'"{uninstaller_path}" /S', shell=True, timeout=300)
        cleanup_ok = True
        if int(completed_process.returncode) == 0:
            print(f'Successfully uninstalled SoundCheck {self.version.to_str()}')
            if cleanup:
                time.sleep(10)  # allow time for uninstall to complete
                cleanup_ok = self.cleanup()
        else:
            print(f'Uninstall failed. Process returned {completed_process.returncode}.')

        return (int(completed_process.returncode) == 0) and cleanup_ok

    def __str__(self):
        return f"WinSCInstallation: {self.path}"

    def __repr__(self):
        return '__repr__ for WinSCInstallation'


class MacSCInstallation(SCInstallation):
    def _launcher_suffix(self):
        return '.*[.]app'

    def _perform_launch(self):
        super(MacSCInstallation, self)._perform_launch()
        payload = Path(str(self.launcher_path()).replace(' ', '\ '), 'Contents', 'MacOS', 'SoundCheck')
        return subprocess.Popen(f"{payload}", shell=True)

    def uninstall(self, cleanup=True):
        """Uninstall SoundCheck, with optional cleanup after.

        :param cleanup: if True, remove the directory after successful uninstall
        :return: status code of the subprocess
        """
        if self.process:
            self.process.terminate()
        cleanup_ok = self.cleanup()
        if cleanup_ok:
            print(f'Successfully uninstalled SoundCheck {self.version.to_str()}')
        else:
            print('Uninstall failed.')

    def __str__(self):
        return f"MacSCInstallation: {self.path}"

    def __repr__(self):
        return '__repr__ for MacSCInstallation'


class RemoteSCInstallation(SCInstallation):
    def __del__(self):
        pass

    @property
    def ini(self):
        return None

    def is_valid(self):
        """Assume that a remote installation is always valid.

        :return: bool True
        """
        return True

    def tcpip_enabled(self):
        """Return whether TCP/IP is already enabled on this installation."""
        return True

    def launcher_path(self):
        "Remote installations don't have a path."
        raise RuntimeError("Remote installations do not have a path.")

    def ini_path(self):
        "Remote installations don't have an INI path"
        raise RuntimeError("Remote installations do not have an INI path.")

    def get_ini_option(self, section, option, default=None, get_type=None):
        raise RuntimeError("Remote installations do not have INI files.")

    def server_details(self):
        return self.ip_address, self.port

    def import_ini(self, new_file):
        raise RuntimeError("INI files cannot be imported with remote installations.")

    def import_har(self, new_file):
        raise RuntimeError("HAR files cannot be imported with remote installations.")

    def import_cal(self, new_file):
        raise RuntimeError("CAL files cannot be imported with remote installations.")

    def import_cal_input_dat(self, new_file):
        raise RuntimeError("CAL files cannot be imported with remote installations.")

    def import_cal_output_dat(self, new_file):
        raise RuntimeError("CAL files cannot be imported with remote installations.")

    def is_running(self):
        """Always assume the installation is running."""
        return True

    def launch(self):
        pass

    def terminate(self):
        pass

    def cleanup(self):
        pass

    def _verify_version(self):
        pass

    def _launcher_suffix(self):
        raise RuntimeError("Cannot determine the suffix of a remote installation.")

    def _perform_launch(self):
        raise RuntimeError("Remote installations cannot be launched.")

    def uninstall(self, cleanup=True):
        raise RuntimeError("Remote installations cannot be uninstalled.")

    def __str__(self):
        return f"RemoteSCInstallation: {self.ip_address}:{self.port}"

    def __repr__(self):
        return '__repr__ for RemoteSCInstallation'


def remove_readonly(func, path, excinfo):
    """"Clear the read only bit and reattempt the removal.

    Pulled from Stack Overflow: https://stackoverflow.com/questions/1889597
    /deleting-directory-in-python/1889686#1889686
    """

    if platform.system() == 'Darwin':
        if excinfo[0] == PermissionError:
            subprocess.run(f'sudo rm -rf "{path}"', shell=True)
        else:
            subprocess.run(f'sudo rm -f "{path}"', shell=True)

        return
    else:
        Path(path).chmod(stat.S_IWRITE)

    func(path)
