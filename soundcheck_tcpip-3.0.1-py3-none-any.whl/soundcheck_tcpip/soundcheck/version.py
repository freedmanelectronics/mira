from __future__ import absolute_import, unicode_literals
import platform
import subprocess
import time
import re
from itertools import takewhile


class SCVersion(tuple):
    """Base class for objects that deal with versions of SoundCheck."""

    def __init__(self, t):
        """Create a new instance of SCVersion.

        :param t: iterable of version numbers, i.e. (major, minor, patch, build)
        """
        super(SCVersion, self).__init__()

    def __new__(cls, t):
        return super(SCVersion, cls).__new__(cls, tuple(t))

    def to_str(self, precision=4, sc_format=False):
        """Get a string representation for this version of SoundCheck.

        Use this method to return a consistently formatted version string
        that includes period separated version numbers from major down to the
        precision specified, where 1=major, 2=minor, 3=patch, and 4=build. If
        sc_format, the separator between minor and patch is omitted.

        :param precision: depth of version numbers to include in the output
        :param sc_format: if True, format the string in traditional SC manner
        :return: str representation of the version
        """
        return self.iter_to_str(self, precision, sc_format)

    @staticmethod
    def iter_to_str(version, precision=None, sc_format=False):
        """Get a string representation of a SoundCheck version.
    
        This function produces a version string from iter up to the precision
        specified. If precision is not given, then the default is to use the
        full precision of version. If sc_format is True, then the second and
        third entries, representing minor and patch version numbers, are 
        combined. A UserWarning will be raised if use_sc_format is enabled 
        and the patch version is >9, since that would create poorly formed 
        version strings.
    
        :param version: iterable of ints representing the version, interpreted
                        as [major, minor, patch, build] (or [w, x, y, z])
        :param precision: int depth of version numbers to include
                          (1=major, 2=minor, 3=patch, 4=build). If None,
                          precision is len(version)
        :param sc_format: boolean flag to use the traditional format for
                          SoundCheck version strings. If True, version string
                          is formatted as ww.xxy.zzzz, else ww.xx.yy.zzzz
        :return: str
        """
        v = list(version)
        if precision is None:
            precision = len(v)
        if not precision >= 0:
            precision = 0
        if len(v) < precision:
            v.extend([0] * (precision - len(v)))

        if sc_format and precision > 2:
            if v[2] > 9:
                raise UserWarning('Patch version above 9 will collide '
                                  'with minor version.')
            v[1:3] = ['{}{}'.format(*v[1:3])]
            precision -= 1

        if precision > len(v):
            precision = len(v)
        return '.'.join([str(x) for x in v[:precision]])

    @classmethod
    def from_str(cls, search_str, prefix=None, sc_format=False):
        """Interpret the SoundCheck version from a string representation.
    
        This function attempts to interpret a SoundCheck version from the
        input string. If sc_format the assumed format is 'ww.xxy.zzzz',
        otherwise 'ww.xx.yy.zzzz' is assumed. If prefix is given, it must
        precede the version numbers in search_str to count as a match. Note
        that prefix matching is case-insensitive. Returns an instance of
        SCVersion that has precision equal to that interpreted from the
        input string.
    
        :param search_str: str representing a version number.
        :param prefix: str to match preceding the version numbers
        :param sc_format: bool flag to interpret from traditional format
        :return: SCVersion
        """
        if not search_str:
            return cls([])
        if prefix is None:
            prefix = ''

        pattern = {False: '((-1|[0-9]+|\^)[.])*(-1|[0-9]+|\^)',
                   True: '([0-9]+[.])*[0-9]+'}[sc_format]

        match = re.search(prefix + pattern, search_str, re.IGNORECASE)
        if match is None:
            return cls([])
        version_str = match.group(0)
        if prefix:
            version_str = re.split(prefix, version_str, maxsplit=1)[1]

        parts = version_str.split('.')
        if sc_format and (len(parts) > 1) and (len(parts[1]) > 1):
            parts[1:2] = [parts[1][:-1], parts[1][-1]]

        version = [int(x) if x != '^' else None for x in parts]
        return cls(version)

    def common_base(self, other):
        """Get the common base version components with other

        :param other: SCVersion or version iterable
        :return: tuple of the common base version
        """
        return self.compare_bases(self, other)

    def is_consistent(self, other):
        """Check if this version is consistent with other.

        Test if this and other could refer to the same version. If both have
        the same precision, then they must be equal. If not, one must be a
        proper subset. If A is consistent with B, then B is also consistent
        with A. If A == B, this is trivially True.

        :param other: SCVersion or version iterable to compare to
        :return: boolean True if both versions are consistent
        """
        if other is None:
            return False
        return self.compare_bases(self, other) in (self, tuple(other))

    @staticmethod
    def compare_bases(this, other):
        """Get the common base version components between this and other.

        :param this: SCVersion or version iterable
        :param other: SCVersion or version iterable
        :return: tuple of the common base versions
        """
        return tuple(x for x, y
                     in takewhile(lambda z: z[0] == z[1], zip(this, other)))


def filter_version_strings(v_strs, version, prefix='', suffix='', sc_format=False):
    """Filter the list of strings to match a version and pattern.

    Look for version with optionally specified prefix and suffix in each
    element of v_strs. Matches are based on a regular expression search and
    obey wildcards included in prefix and suffix. Return the list of matching
    strings.

    :param v_strs: list of str to search
    :param version: desired version to search for, or None to omit
    :param prefix: re string to match before version in each str
    :param suffix: re string to match after version in each str
    :param sc_format: if True, version is formatted as 'ww.xxy.zzzz'
    :return: list of matching strings
    """
    version_str = ''
    version_cutoff = ''
    if version is not None:
        version_str = SCVersion.iter_to_str(version, sc_format=sc_format)
        # Match to the highest version if empty
        if not version_str:
            version_str = '[0-9]+'
        # Don't match to trailing numbers
        # (e.g., exclude 229 when looking for 22)
        version_cutoff = '(?![0-9])'

        if sc_format and len(version) == 2:
            # Make an exception for the old SoundCheck formatting
            # (e.g., allow 17.22 when looking for 17.2)
            version_cutoff = '[0-9]?' + version_cutoff

    pattern = re.compile(''.join([prefix, version_str, version_cutoff, suffix]),
                         re.IGNORECASE)

    return [f for f in v_strs if pattern.search(str(f))]


def get_file_version(path, max_attempts=60):
    """Retrieve the version encoded in the file at path.

    Depending on when and how the file was created, it may take several
    seconds for the version info to become available. This method compensates
    by trying to read the info once a second for up to max_attempts.

    :param path: path to the file of interest
    :param max_attempts: maximum number of times to try reading the version
    :return: instance of SCVersion matching file version or None if not found
    """
    if platform.system() == 'Darwin':
        try:
            v_str = subprocess.check_output(['defaults', 'read',
                                             path / 'Contents' / 'Info', 'CFBundleShortVersionString'])
        except subprocess.CalledProcessError:
            return None

        return SCVersion.from_str(v_str.decode('utf-8'))
    else:
        import win32api

        try:
            version_info = win32api.GetFileVersionInfo(str(path), '\\')
            v_bin = ''.join([format(version_info[x], '032b')
                             for x in ('FileVersionMS', 'FileVersionLS')])
            return SCVersion([int(v_bin[i:i + 16], 2)
                              for i in range(0, len(v_bin), 16)])
        except win32api.error:
            pass

    return None
