from __future__ import absolute_import, unicode_literals

import base64
import json
import os
import socket
import sys
import time
from contextlib import contextmanager
from json import JSONEncoder
from pathlib import Path

import numpy as np

os.environ['_JAVA_OPTIONS'] = '-Xmx512M'


class SCControlTCPIP:
    def __init__(self, installation):
        self.installation = installation
        if not self.installation.tcpip_enabled():
            self.enable_tcpip()

    @contextmanager
    def socket(self, timeout=10):
        """Open and close a connection to SoundCheck for communication.

        Creates a socket connection to SoundCheck using the server details
        provided by the installation. The welcome message is discarded before
        yielding the socket. Once returned, the socket is shutdown and closed.

        :return: an open, connected socket to SoundCheck
        """
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect(self.installation.server_details())
        sock.settimeout(timeout)
        sock.recv(50)  # receive welcome message

        yield sock

        sock.shutdown(socket.SHUT_RDWR)
        sock.close()

    def send_command(self, command, sock=None, receive_buffer=4096,
                     receive_timeout=60, discard_response=False):
        """Send a command to SoundCheck and receive the response.

        :param command: command to send
        :param sock: optional socket to use. If none, a temp socket is used
        :param receive_buffer: number of bytes to read per chunk
        :param receive_timeout: seconds to wait for the response
        :param discard_response: if False, parse and return the response
        :return: dict of response data or None if discard_response
        """

        def send_data():
            """Send the data over the socket, checking each time that all the data
            was sent.  If not, keep repeating until all the data is sent over."""

            data_size = len(command)
            total_data_sent = 0

            while total_data_sent < data_size:
                data_sent = sock.send(command[total_data_sent:])
                total_data_sent += data_sent

        if sys.version_info < (3, 0):
            command = bytes(command)
        else:
            command = bytes(command, 'utf8')
        command += b'\r\n'

        if sock:
            current_timeout = sock.gettimeout()
            sock.settimeout(receive_timeout)
            send_data()
            response = self.read_response(sock, receive_buffer)
            sock.settimeout(current_timeout)
        else:
            with self.socket(timeout=receive_timeout) as sock:
                send_data()
                response = self.read_response(sock, receive_buffer)

        if not discard_response:
            return self.parse_response(response)

    @staticmethod
    def read_response(sock, receive_buffer=4096):
        """Read a response from socket.

        Read from the socket in chunks of receive_buffer bytes at a time, and
        continue reading chunks until the end of line characters are returned.

        By default, the receive buffer is set to 4096 bytes. This allows most
        return strings to fit in one buffer. Curves and waveforms are
        generally much larger, so decreasing the buffer size would increase
        the number of chunks required to complete.

        :param sock: Enabled TCP/IP socket from which to receive data
        :param receive_buffer: number of bytes to read per chunk
        :return: bstr response from the socket
        """
        end_line = b'\r\n'
        read_lines = [b'']
        while end_line not in read_lines[-1]:
            next_line = sock.recv(receive_buffer)
            if not next_line:
                break
            read_lines.append(next_line)
        return b''.join(read_lines).decode('utf-8')

    @staticmethod
    def parse_response(response):
        """Interpret a json response received from SoundCheck.

        Checks that a command was completed and, if so, returns data.
        Otherwise an exception is raised with error information.

        :param response: response from SoundCheck
        :return: "returnData" if command completed
        """
        js = json.loads(response)
        if not js['cmdCompleted'] or js['errorType']:
            raise RuntimeError(f"SoundCheck command did not complete: "
                               f"{js['errorDescription']}: "
                               f"{js['errorType']}: "
                               f"{js['originalCommand']}: {response}")
        return js['returnData']

    def enable_tcpip(self):
        """Enable the TCP/IP server option in SoundCheck settings."""
        self.installation.set_ini_option('External Control',
                                         'TCP IP SERVER ENABLED', 'True')

    def launch(self, timeout=30):
        """Start SoundCheck and wait for it to reach a ready state.

        Will launch SoundCheck if given installation is not already running
        and then wait for it to open and reach a ready state. If SoundCheck
        does not load or become ready within timeout an exception will be
        raised.

        :param timeout: maximum time to wait before raising an exception
        """
        if not self.installation.is_running():
            self.installation.launch()

        # give SC some time to startup. SoundCheck Mac is very slow.
        nap_time = 30 if sys.platform == 'darwin' else 5

        if self.wait_on_open(timeout + nap_time):
            raise Exception('SoundCheck did not respond within the timeout')
        print('TCP/IP Controller Connected. Waiting on SoundCheck...')

        if self.wait_on_ready(timeout):
            raise Exception(
                'SoundCheck did not become ready within the timeout')
        print('SoundCheck Ready')

    def close(self, timeout=5):
        """Send SoundCheck a shutdown command and force exit if necessary.

        :param timeout: seconds to wait after sending shutdown command before
                        force killing SoundCheck
        """

        #
        # wrap the call to SoundCheck.Exit in try/finally so that in
        # the case when SoundCheck.Exit times out on the SoundCheck side
        # we catch the timeout error and cleanup as intended.
        # Note, SoundCheck.Exit has an internal timeout of 7.5 secs. This
        # is not enough if there's a large sequence loaded.
        #
        try:
            if self.installation.send_exit():
                self.send_command('SoundCheck.Exit')
                time.sleep(timeout)
        except:
            pass
        finally:
            self.installation.terminate()

    def wait_on_open(self, timeout=30):
        """Waits for SoundCheck to open the TCP/IP server on given port.

        Will kill SoundCheck process if the port does not open within the
        timeout.

        :param timeout: seconds to wait for the port to open
        :return: 0 if successful or 1 otherwise
        """
        # check that given installations process is valid
        if not self.installation.is_running():
            return 1

        t_end = time.time() + timeout
        while time.time() < t_end:
            if self.installation.is_running():
                try:
                    with self.socket() as sock:
                        return 0
                except socket.error:
                    time.sleep(1)
            else:
                # SoundCheck is no longer running, break and exit
                break

        self.installation.terminate()
        return 1

    def wait_on_ready(self, timeout=30):
        """Wait for SoundCheck to return "ready" or not busy.

        Will kill SoundCheck process if ready is not returned within timeout.

        :param timeout: seconds to wait for SoundCheck to report not busy
        :return: 0 if successful or 1 otherwise
        """
        t_end = time.time() + timeout
        while time.time() < t_end:
            if not self.get_is_busy():
                return 0
            else:
                time.sleep(1)
        self.installation.terminate()
        return 1

    def is_running(self):
        return self.installation.is_running()

    # methods below correspond to specific SoundCheck api commands
    # ==========================================================================

    def get_is_busy(self):
        """Query SoundCheck for busy status.

        :return: True if SoundCheck is busy, False if SoundCheck is ready to
                 receive another command
        """
        response = self.send_command(command='SoundCheck.GetStatus')
        return response["Busy"]

    def set_login_level(self, level=0):
        """Sets the login level for SoundCheck

        :param level: 0 - Engineer, 1 - Technician, 2 - Operator"""

        self.send_command(f"SoundCheck.SetLoginLevel('{level}')")

    def get_login_level(self):
        """Returns the login level in use by SoundCheck

        :return the login level"""

        return self.send_command("SoundCheck.GetLoginLevel")['Value']

    def set_user_name(self, user_name=''):
        """Sets the user name of the currently logged in user.

        :param user_name: name of the currently logged in user"""

        self.send_command(f"SoundCheck.SetUserName('{user_name}')")

    def get_user_name(self):
        """Gets the user name of the currently logged in user.

        :return name of the currently logged in user"""

        return self.send_command("SoundCheck.GetUserName")['Value']

    def set_serial_number(self, serial_number=''):
        """Set the serial number of the device under test.

        :param serial_number: the serial number of the DUT"""

        self.send_command(f"SoundCheck.SetSerialNumber('{serial_number}')")

    def get_serial_number(self):
        """Gets the serial number of the device under test.

        :return the serial number of the DUT"""

        return self.send_command("SoundCheck.GetSerialNumber")['Value']

    def set_lot_number(self, lot_number):
        """Set the lot number used in SoundCheck.

        :param lot_number: value to set the lot number to"""

        self.send_command("SoundCheck.SetLotNumber('{!s}')".format(lot_number))

    def get_lot_number(self):
        """Returns the lot number in use by SoundCheck.

        :return the lot number"""

        return self.send_command("SoundCheck.GetLotNumber")['Value']

    def get_license_status(self):
        """Gets the license status of SoundCheck.  Return values indicate
        whether a valid hardware key was found, and if so what the key ID is.

        :return tuple with the first element the valid status and the second
        the key ID"""

        response = self.send_command("SoundCheck.GetLicenseStatus")

        return response['Valid'], response['KeyID']

    def get_root_path(self):
        """Gets the path to the SoundCheck root folder.

        :return Path to the SoundCheck root folder"""

        response = self.send_command("SoundCheck.Paths")

        return Path(response['Root'])

    def get_ini_path(self):
        """Gets the path to the SoundCheck INI file.

        :return Path to the SoundCheck INI file"""

        response = self.send_command("SoundCheck.Paths")

        return Path(response['INI'])

    def get_dvr_creators(self):
        """Gets the list of DVR creators.

        :return List of DVR creators"""

        return self.send_command("SoundCheck.GetDVRCreators")['Value']

    def request_deallocation(self):
        """Request LabVIEW to deallocate memory."""

        self.send_command("SoundCheck.RequestDeallocation")

    def open_sequence(self, path, timeout=60):
        """Send a command to SoundCheck to load the sequence file at path.

        :param path: path to sequence file
        :param timeout: seconds to wait for a response until timeout
        :return: dict of SoundCheck response
        """
        return self.send_command(f"Sequence.Open('{path}')", receive_timeout=timeout)

    def current_sequence(self):
        """Send a command to SoundCheck to request the current sequence name."""
        return self.send_command("Sequence.GetName")['Value']

    def run_sequence(self, path=None, timeout=300, iterations=1, respond=True, pre_iter=None, post_iter=None):
        """Send a command to SoundCheck to run a sequence.

        If specified, the sequence file at path is loaded before the run
        command is sent.

        Runs sequence with specified timeout, default in SC is 5 minutes per
        sequence run so that is copied here. The socket is given a few extra
        seconds to timeout on top of this value. Attempts to run the sequence
        for the number of iterations specified, default of 1.

        :param path: optional path to sequence file
        :param timeout: seconds to allow the sequence to complete
        :param iterations: number of times to run the sequence
        :param respond: if true all response strings are returned, otherwise
                        method returns None
        :param pre_iter: if not None, an iterable that will get run before each
                        iteration step
        :param post_iter: if not None, an iterable that will get run after each
                        iteration step
        :return: list of response structures for each run
        """

        if path:
            self.open_sequence(path)
            time.sleep(.5)
        if not self.current_sequence():
            print(self.current_sequence())
            raise RuntimeWarning('No sequence loaded.')

        cmd = "Sequence.Run"
        if timeout:
            cmd += f"('{timeout * 1000}')"

        responses = []
        for i in range(iterations):
            if pre_iter is not None:
                pre_iter()

            response = self.send_command(cmd, receive_timeout=timeout + 15,
                                         discard_response=not respond)

            if post_iter is not None:
                post_iter()

            if respond:
                responses.append(response if response else b'')

        return responses if respond else None

    def save_sequence(self, timeout=10):
        """Sends a request to SoundCheck to save the currently open sequence."""

        self.send_command("Sequence.Save", receive_timeout=timeout)

    def get_sequence_duration(self):
        """Gets the duration of the last run sequence.

        :return duration of the last run"""

        return self.send_command("Sequence.GetDuration")['Value']

    def get_sequence_path(self):
        """Gets the path of the currently open sequence.

        :return path to the currently open sequence"""

        return self.send_command("Sequence.GetPath")['Value']

    def get_sequence_steps_list(self):
        """Returns a list of dicts containing the steps in the currently
         open sequence.  Each dict has the following keys:

             'Name': name of the step
             'Type': type of step
             'InputChannelNames': list of input channel names
             'OutputChannelNames': list of output channel names

        :return list of dicts with the sequence steps."""

        return self.send_command("Sequence.GetStepsList")

    def get_memlist_names(self, data_type=None):
        """Get the names of all items in the SoundCheck memory list.

        This queries SoundCheck for the names of all items currently defined
        in the memory list. Returned names are grouped by data type (i.e.,
        'Curves', 'Values', 'Results', and 'Waveforms'.

        :param data_type: data type to return, or all types if None
        :return: dict of name lists keyed by data type, or list if only one
                 data type is selected
        """
        response = self.send_command('MemoryList.GetAllNames')

        if data_type is None:
            return response
        else:
            return response.get(data_type, [])

    def get_memlist_data(self, data_type, data_name, encoding=''):
        """Get named data of data_type from SoundCheck's memory list.

        If the item is not found in the memory list, a ValueError is raised.

        :param data_type: 'Curve', 'Waveform', 'Result', or 'Value'
        :param data_name: name of the data to look for and return
        :return: Full response if found
        """
        if data_type not in ['Curve', 'Waveform', 'Result', 'Value']:
            raise ValueError(f'\'{data_type}\' is not a valid data type')

        cmd = f"MemoryList.Get('{data_type}', '{data_name}', '{encoding}')"

        receive_buffer = 4096
        if data_type in ['Curve', 'Waveform']:
            receive_buffer *= 4

        response = self.send_command(cmd, receive_buffer=receive_buffer)

        if not response['Found']:
            raise ValueError(f'Could not find {data_type} with name \'{data_name}\' in Memory List')
        return response[data_type]

    def get_result(self, name):
        """Get a result from the memory list.

        If the result is not found in the memory list, a ValueError is raised.

        :param name: result name
        :return: Result section of response if found
                 keys: Name, Passed, Limit, Margin, Max/Min, Scale, Unit,
                 Protected, Metadata
        """
        return self.get_memlist_data('Result', name)

    def get_value(self, name):
        """Get a value from the memory list.

        If the value is not found in the memory list, a ValueError is raised.

        :param name:
        :return: Value section of response
                 keys: Name, XData, YData, ZData, XUnit, YUnit, ZUnit,
                 XDataScale, YDataScale, ZDataScale, XdBRef, YdBRef, ZdBRef,
                 XAxisScale, YAxisScale, ZAxisScale, Protected, Metadata
        """
        return self.get_memlist_data('Value', name)

    def get_curve(self, name):
        """Get a curve from the memory list.

        If the curve is not found in the memory list, a ValueError is raised.

        :param name:
        :return: Curve section of response
                 keys: Name, XData, YData, ZData, XUnit, YUnit, ZUnit,
                 XDataScale, YDataScale, ZDataScale, XdBRef, YdBRef,
                 ZdBRef, XAxisScale, YAxisScale, ZAxisScale, Protected, Metadata
        """
        return self.get_memlist_data('Curve', name)

    def get_waveform(self, name, encoding=''):
        """Get a waveform from memory list.

        If the waveform is not found in the memory list, a ValueError is
        raised.

        :param name:
        :return: Waveform waveform section of response
                 keys: Name, Waveform (keys: X0, dX, YData) XUnit, YUnit,
                 YDataScale, YdBRef, YAxisScale, Overload?, Protected, Metadata
        """
        waveform = self.get_memlist_data('Waveform', name, encoding=encoding)
        if encoding == 'base64':
            try:
                float_arr = np.frombuffer(base64.b64decode(waveform["Waveform"]["YData"], altchars=None,
                                                           validate=True), dtype=np.double).tolist()
                waveform["Waveform"]["YData"] = float_arr
            except KeyError:
                pass
        return waveform

    def get_all_data(self, encoding=''):
        """Get all the data in the ML.

        :return: dict containing all the data in the ML
        """
        cmd = "MemoryList.GetAllData"
        cmd = f"MemoryList.GetAllData('{encoding}')"
        data = self.send_command(cmd)
        if encoding == 'base64':
            for waveform in data["Waveforms"]:
                waveform["Waveform"]["YData"] = np.frombuffer(
                    base64.b64decode(waveform["Waveform"]["YData"], altchars=None, validate=True),
                    dtype=np.double).tolist()
        return data

    def set_memlist_data(self, data_type, data_name, data_args, encoding=''):
        """Set a Value, Curve, or Waveform in the Memory List

        :param data_type: 'Curve', 'Value', or 'Waveform'
        :param data_name: name of the Memory List data
        :param data_args: dictionary with all the command arguments

        :return SoundCheck response"""

        def arg_to_argstr(arg_name, arg_value):
            """Convert a name/value pair into a suitable string for sending to
            SoundCheck.

            :param arg_name: name of the argument
            :param arg_value: value of the argument

            :return string representation of the name/value pair"""
            arg_str = ""
            arg_type = type(arg_value)

            if arg_type is dict:
                #
                # for dict values, recurse
                #
                arg_str = f"\"{arg_name}\":{{"
                for arg_key in arg_value:
                    arg_str += arg_to_argstr(arg_key, arg_value[arg_key])
                arg_str = arg_str[:-1] + "},"
            elif arg_type is bool:
                #
                # bool's just get "true" or "false"
                #
                arg_str += "\"{}\":{},".format(arg_name, "true" if arg_value else "false")
            elif arg_type in [int, float, np.float_]:
                #
                # int and floats get their value w/o quotes
                #
                arg_str += "\"" + arg_name + "\":" + str(arg_value) + ","
            elif arg_type is np.ndarray:
                #
                # np arrays get converted to "[x0,x1,...,xn]"
                #
                arg_str += "\"" + arg_name + "\":[" + ",".join(arg_value.astype(float).astype(str)) + "],"
            else:
                #
                # anything else just gets wrapped in quotes
                #
                arg_str = f"\"{arg_name}\":\"{arg_value}\","

            return arg_str

        if data_type not in ['Curve', 'Waveform', 'Value']:
            raise ValueError(f'\'{data_type}\' is not a valid data type')

        #
        # set up the beginning fo the command
        #
        cmd = f"MemoryList.Set('{data_type}', '{{\"Name\":\"{data_name}\","

        #
        # add in the data values
        #
        cmd += json.dumps(data_args, cls=NumpyArrayEncoder)[1:]
        self.send_command(cmd[:-1] + "}'" + f",'{encoding}')")

    def set_value(self, data_name,
                  x_data=0.0, y_data=0.0, z_data=0.0,
                  x_unit='', y_unit='', z_unit='',
                  x_data_scale='Lin', y_data_scale='Lin', z_data_scale='Lin',
                  xdb_ref=1, ydb_ref=1, zdb_ref=1,
                  protected=False, metadata=None):
        """Set a named Value in the Memory List.

        :param data_name: name of the data to set
        :param x_data: The X data for the value.
        :param y_data: The Y data for the value.
        :param z_data: The Z data for the value.
        :param x_unit: String containing the units for the X data.
        :param y_unit: String containing the units for the Y data.
        :param z_unit: String containing the units for the X data.
        :param x_data_scale: The data scale ('Lin', 'Log') of the X data.
        :param y_data_scale: The data scale ('Lin', 'Log') of the Y data.
        :param z_data_scale: The data scale ('Lin', 'Log') of the Z data.
        :param xdb_ref: The dB reference for the X data.
        :param ydb_ref: The dB reference for the Y data.
        :param zdb_ref: The dB reference for the Z data.
        :param protected: True if the curve, value, or waveform is to be protected.
        :param metadata: Dictionary of name-value metadata pairs
        :return response from SoundCheck"""

        #
        # for values, the X, Y, and Z data all need to be defined and be scalars
        #
        if not x_data:
            x_data = 1.0
        if not y_data:
            y_data = 0.0
        if not z_data:
            z_data = 0.0

        if metadata is None:
            metadata = {}
        pairs = []
        for key, value in metadata.items():
            pairs.append({"Metadata": {"Name": key, "Default Value": value, "Value": value}})

        #
        # build up the args dict
        #
        args = {
            "XData": x_data, "YData": y_data, "ZData": z_data,
            "XUnit": x_unit, "YUnit": y_unit, "ZUnit": z_unit,
            "XDataScale": x_data_scale, "YDataScale": y_data_scale, "ZDataScale": z_data_scale,
            "XdBRef": xdb_ref, "YdBRef": ydb_ref, "ZdBRef": zdb_ref,
            "Protected": protected, "Metadata": {"Schema": "DefaultMetadataContainerSchema",
                                                 "Pairs": pairs}
        }

        #
        # send and return the response
        #
        self.set_memlist_data("Value", data_name, args)

    def set_curve(self, data_name,
                  x_data=np.array([]), y_data=np.array([]), z_data=np.array([]),
                  x_unit='', y_unit='', z_unit='',
                  x_data_scale='Lin', y_data_scale='Lin', z_data_scale='Lin',
                  xdb_ref=1, ydb_ref=1, zdb_ref=1,
                  x_axis_scale='Lin', y_axis_scale='Lin', z_axis_scale='Lin',
                  protected=False, metadata=None):

        """Set a named Curve in the Memory List.

        :param data_name: name of the data to set
        :param x_data: The X data for the curve.
        :param y_data: The Y data for the curve.
        :param z_data: The Z data for the curve.
        :param x_unit: String containing the units for the X data.
        :param y_unit: String containing the units for the Y data.
        :param z_unit: String containing the units for the X data.
        :param x_data_scale: The data scale ('Lin', 'Log') of the X data.
        :param y_data_scale: The data scale ('Lin', 'Log') of the Y data.
        :param z_data_scale: The data scale ('Lin', 'Log') of the Z data.
        :param xdb_ref: The dB reference for the X data.
        :param ydb_ref: The dB reference for the Y data.
        :param zdb_ref: The dB reference for the Z data.
        :param x_axis_scale: The axis scale ('Lin', 'Log') of the X data.
        :param y_axis_scale: The axis scale ('Lin', 'Log') of the Y data.
        :param z_axis_scale: The axis scale ('Lin', 'Log') of the Z data.
        :param protected: True if the curve, value, or waveform is to be protected.
        :param metadata: Dictionary of name-value metadata pairs
        :return response from SoundCheck"""

        #
        # for curves, the X, Y, and Z data all need to be defined and be
        # the same size
        #
        data = x_data if any(x_data) else (y_data if any(y_data) else z_data)
        if not any(x_data):
            x_data = np.arange(1, data.size + 1, 1)
        if not any(y_data):
            y_data = np.zeros(data.shape)
        if not any(z_data):
            z_data = np.zeros(data.shape)

        if metadata is None:
            metadata = {}
        pairs = []
        for key, value in metadata.items():
            pairs.append({"Metadata": {"Name": key, "Default Value": value, "Value": value}})
        #
        # build up the args dict
        #
        args = {
            'XData': x_data, 'YData': y_data, 'ZData': z_data,
            'XUnit': x_unit, 'YUnit': y_unit, 'ZUnit': z_unit,
            'XDataScale': x_data_scale, 'YDataScale': y_data_scale, 'ZDataScale': z_data_scale,
            'XdBRef': xdb_ref, 'YdBRef': ydb_ref, 'ZdBRef': zdb_ref,
            'XAxisScale': x_axis_scale, 'YAxisScale': y_axis_scale, 'ZAxisScale': z_axis_scale,
            'Protected': protected, "Metadata": {"Schema": "DefaultMetadataContainerSchema",
                                                 "Pairs": pairs}
        }
        #
        # send and return the response
        #
        self.set_memlist_data('Curve', data_name, args)

    def set_waveform(self, data_name,
                     x0=0.0, dX=1.0, y_data=np.array([]),
                     x_unit='v', y_unit='d', y_data_scale='Lin', ydb_ref=1, y_axis_scale='Lin',
                     overload=False, protected=False, metadata=None, encoding=''):
        """Set a named Waveform in the Memory List.

        :param data_name: name of the data to set
        :param x0: The starting X value for the waveform.
        :param dX: The increment between X values.
        :param y_data: The Y data for the waveform.
        :param x_unit: String containing the units for the X data.
        :param y_unit: String containing the units for the Y data.
        :param y_data_scale: The data scale ('Lin', 'Log') of the Y data.
        :param ydb_ref: The dB reference for the Y data.
        :param y_axis_scale: The axis scale ('Lin', 'Log') of the Y data.
        :param overload: True if the waveform has overloaded.
        :param protected: True if the curve, value, or waveform is to be protected.
        :param metadata: Dictionary of name-value metadata pairs
        :return response from SoundCheck"""

        #
        # for curves, the X, Y, and Z data all need to be defined and be
        # the same size
        #
        if not any(y_data):
            raise ValueError("Y data cannot be empty for a Waveform")
        if metadata is None:
            metadata = {}
        pairs = []
        for key, value in metadata.items():
            pairs.append({"Metadata": {"Name": key, "Default Value": value, "Value": value}})
        #
        # build up the args dict
        #
        args = {
            "Waveform": {"X0": x0, "dX": dX,
                         "YData": base64.b64encode(
                             np.array(y_data).astype(np.float64)).decode() if encoding == 'base64' else y_data},
            "XUnit": x_unit, "YUnit": y_unit,
            "YDataScale": y_data_scale, "YdBRef": ydb_ref, "YAxisScale": y_axis_scale,
            "Overload?": overload, "Protected": protected, "Metadata": {"Schema": "DefaultMetadataContainerSchema",
                                                                        "Pairs": pairs}
        }

        #
        # send and return the response
        #
        self.set_memlist_data('Waveform', data_name, args, encoding)

    def set_metadata(self, data_name="", metadata=None, merge=True):
        """Set metadata in the Memory List.

        :param data_name: name of the data to set
        :param metadata: dictionary containing metadata
        :param merge: True merges metadata with the already existing one, False replaces all the metadata
        :return: response from SoundCheck
        """

        if metadata is None:
            metadata = {}
        pairs = []
        for key, value in metadata.items():
            pairs.append({"Metadata": {"Name": key, "Default Value": value, "Value": value}})
        #
        # build up the args dict
        #
        args = {'Name': data_name,
                'Metadata': {"Schema": "DefaultMetadataContainerSchema",
                             "Pairs": pairs},
                'Merge': merge
                }

        #
        # set up the beginning fo the command
        #
        cmd = f"MemoryListSetMetadata('{{"

        #
        # add in the data values
        #

        cmd += json.dumps(args, cls=NumpyArrayEncoder)[1:]
        self.send_command(cmd[:-1] + "}')")

    def get_metadata(self, name):
        """Get metadata from the memory list

        :param name: the name of the item in the memory list
        :return: a dictionary containing the metadata of the item in the memory list
        """
        cmd = f"MemoryListGetMetadata('{name}')"

        return self.send_command(cmd)

    def set_sequence_metadata(self, metadata=None):
        """

        :param metadata: dictionary containing sequence metadata
        :param append: True appends metadata to the already existing one, False replaces all the metadata
        :return: SoundCheck response
        """

        if metadata is None:
            metadata = {}
        pairs = []
        for key, value in metadata.items():
            pairs.append({"Metadata": {"Name": key, "Default Value": value, "Value": value}})
        #
        # build up the args dict
        #
        args = {'Metadata': {"Schema": "DefaultMetadataContainerSchema",
                             "Pairs": pairs},
                }
        #
        # set up the beginning fo the command
        #
        cmd = f"SequenceSetMetadata('{{"

        #
        # add in the data values
        #

        cmd += json.dumps(args, cls=NumpyArrayEncoder)[1:]
        self.send_command(cmd[:-1] + "}')")

    def get_sequence_metadata(self):
        """Get sequence metadata

        :return: dictionary containing sequence metadata
        """

        return self.send_command("SequenceGetMetadata")


class NumpyArrayEncoder(JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        return JSONEncoder.default(self, obj)
