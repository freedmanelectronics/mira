from __future__ import absolute_import, unicode_literals
from pathlib import Path
from .version import SCVersion


class SCAgent(object):
    """Class to keep track of a particular available SoundCheck agent.

    Agents provide a pathway to a SoundCheck installation with a specific
    version. This includes installations, installers, and updaters."""

    def __init__(self, version=None, path=Path(), ip_address=None, port=None):
        self.version = SCVersion(version) if version else None
        self.path = path
        self.agent_type = 'base_agent'
        self.ip_address = ip_address
        self.port = port

    def __str__(self):
        return f'{self.__class__.__name__} {self.version.to_str()}, path: {self.path}'

    def __repr__(self):
        return '_'.join([self.__class__.__name__, self.version.to_str()])

    def __hash__(self):
        return hash(self.version)

    def __eq__(self, other):
        if issubclass(other.__class__, SCAgent):
            return self.version == other.version
        else:
            if other is None:
                return self is None
            return self.version[:len(other)] == tuple(other)

    def __ne__(self, other):
        return not self.__eq__(other)

    def __lt__(self, other):
        if issubclass(other.__class__, SCAgent):
            return self.version < other.version
        else:
            return self.version < tuple(other)

    def __gt__(self, other):
        if issubclass(other.__class__, SCAgent):
            return self.version > other.version
        else:
            return self.version > tuple(other)

    def __le__(self, other):
        return self.__lt__(other) or self.__eq__(other)

    def __ge__(self, other):
        return self.__gt__(other) or self.__eq__(other)

    def common_base_version(self, other):
        """Get the common base version components with other

        :param other: SCAgent, SCVersion or version iterable
        :return: tuple of the common base version
        """
        if issubclass(other.__class__, SCAgent):
            return self.version.common_base(other.version)
        else:
            return self.version.common_base(other)

    def get_activation_prerequisites(self):
        """Get the prerequisites for activating this agent.

        Override this method to define activation prerequisites. For example,
        if this is an updater, an active installation having the same major
        version number but lower total version is required for a successful
        update. If it is an installer, any active installation with the same
        major and minor version will conflict.

        requirements are given by a range of versions. At least one
        installation of SoundCheck within the range specified by
        require_v_min and require_v_max (excluding any versions given in
        require_v_exceptions) must be present to successfully activate this
        agent.

        conflicts are also given by a range of versions. If any installations
        of SoundCheck within the range specified by conflict_v_min and
        conflict_v_max (excluding any versions given in
        conflict_v_exceptions) are active, they must be uninstalled to
        successfully activate this agent.


        :return: dict of requirements
        """
        return {'require_v_min': [-1] * 4, 'require_v_max': [],
                'require_v_exceptions': [],
                'conflict_v_min': [-1] * 4, 'conflict_v_max': [],
                'conflict_v_exceptions': []}

    def activate(self, timeout=None):
        """Activate this agent so that it can be found as an installation.

        Perform the necessary actions to activate this agent (install,
        update, etc) so that this version will show up as an installation on
        the system. Since agents have no knowledge of the system, this method
        does not check for conflicting or required installations.

        :param timeout: amount of time activation should take before timing out
        :return: bool True if activation successful, else False
        """
        raise NotImplementedError
