# list of modules to import when the soundcheck_tcpip package is imported
__all__ = ['soundcheck']

from soundcheck_tcpip.sctcpip_version import get_version

__version__ = get_version()
