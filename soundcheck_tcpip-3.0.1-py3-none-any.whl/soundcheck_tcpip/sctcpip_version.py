import importlib.metadata
base_version = '22.0.0'

# use distribution version rather than spl_version to make dev versioning available to user


def get_version():
    try:
        ver = importlib.metadata.version("soundcheck")
    except importlib.metadata.PackageNotFoundError:
        ver = base_version
    return ver
